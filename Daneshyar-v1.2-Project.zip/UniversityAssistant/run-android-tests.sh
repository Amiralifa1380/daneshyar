#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
trap 'adb logcat -d > emulator.log || true' EXIT
adb logcat -c
gradle --no-daemon :app:connectedDebugAndroidTest --stacktrace
