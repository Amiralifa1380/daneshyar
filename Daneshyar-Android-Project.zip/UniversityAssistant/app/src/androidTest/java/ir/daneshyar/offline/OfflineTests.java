package ir.daneshyar.offline;
import android.app.Instrumentation;
import android.app.Activity;
import android.content.*;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.view.ViewGroup;
import org.json.JSONObject;
import java.util.Calendar;
/** Dependency-free on-device integration tests. Never run against the user's database. */
public final class OfflineTests extends Instrumentation {
    private int checks=0;
    private void check(boolean condition,String name) {
        Bundle status=new Bundle();
        status.putString("class",getClass().getName());
        status.putString("test",name);
        status.putInt("numtests",17);
        status.putInt("current",checks+1);
        sendStatus(1,status);
        if(!condition) {
            status.putString("stack","AssertionError: "+name);
            sendStatus(-2,status);
            throw new AssertionError(name);
        }
        checks++;
        sendStatus(0,status);
    }
    @Override public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        start();
    }
    @Override public void onStart() {
        Bundle result=new Bundle();
        try {
            getContext().deleteDatabase("daneshyar.db");
            try(Store db=new Store(getContext())) {
                ContentValues teacher=new ContentValues();
                teacher.put("name","استاد آزمون");
                long t=db.save("teachers",0,teacher);
                ContentValues course=new ContentValues();
                course.put("name","ریاضی");
                course.put("teacher_id",t);
                course.put("units",3);
                course.put("grade",18.5);
                long c=db.save("courses",0,course);
                check(db.get("courses",c).optDouble("grade")==18.5,"grade persistence");
                ContentValues session=new ContentValues();
                session.put("course_id",c);
                session.put("day",0);
                session.put("start",540);
                session.put("end",600);
                session.put("remind",15);
                long s=db.save("sessions",0,session);
                ContentValues event=new ContentValues();
                event.put("title","امتحان");
                event.put("kind",0);
                event.put("course_id",c);
                event.put("due",System.currentTimeMillis()+3600000L);
                event.put("lead",15);
                long e=db.save("events",0,event);
                JSONObject backup=db.backup();
                check(backup.getJSONArray("events").length()==1,"backup contains event");
                event.put("title","ویرایش");
                db.save("events",e,event);
                check(db.get("events",e).optString("title").equals("ویرایش"),"update");
                db.restore(backup);
                check(db.get("events",e).optString("title").equals("امتحان"),"restore original");
                JSONObject bad=new JSONObject(backup.toString());
                bad.getJSONArray("courses").getJSONObject(0).put("units",99);
                boolean rejected=false;
                try {
                    db.restore(bad);
                }
                catch(Exception expected) {
                    rejected=true;
                }
                check(rejected&&db.get("courses",c).optInt("units")==3,"invalid restore rollback");
                db.delete("teachers",t);
                check(db.get("courses",c).isNull("teacher_id"),"teacher nullifies link");
                db.delete("courses",c);
                check(db.all("sessions").isEmpty(),"course cascades sessions");
                check(db.get("events",e).isNull("course_id"),"course preserves event");
                db.restore(backup);
                check(db.all("teachers").size()==1,"restore teacher");
                JSONObject row=db.get("sessions",s);
                Calendar now=Calendar.getInstance();
                now.set(2026,Calendar.OCTOBER,17,8,0,0);
                now.set(Calendar.MILLISECOND,0);
                long next=Reminders.nextSession(row,now.getTimeInMillis());
                check(next-now.getTimeInMillis()==45*60000L,"Saturday reminder");
                check(Reminders.nextSession(row,next)==next+7*86400000L,"next week after delivered");
            }
            check(PersianDates.minutes("۰۹:۳۰")==570,"Persian digit time");
            check(PersianDates.date(PersianDates.parse("۱۴۰۵/۰۷/۲۲","۱۳:۲۱")).equals("1405/07/22"),"Persian date round trip");
            Calendar date=Calendar.getInstance();
            date.setTimeInMillis(PersianDates.parse("1405/07/22","13:21"));
            check(date.get(Calendar.YEAR)==2026&&date.get(Calendar.MONTH)==9&&date.get(Calendar.DAY_OF_MONTH)==14,"known Gregorian mapping");
            boolean rejected=false;
            try {
                PersianDates.parse("1405/07/31","09:00");
            }
            catch(Exception expected) {
                rejected=true;
            }
            check(rejected,"invalid Persian date rejected");
            rejected=false;
            try {
                PersianDates.parse("1405/01/01","24:00");
            }
            catch(Exception expected) {
                rejected=true;
            }
            check(rejected,"invalid time rejected");
            Intent launch=new Intent(getTargetContext(),MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Activity activity=startActivitySync(launch);
            waitForIdleSync();
            runOnMainSync(()-> {
                check(containsText(activity.getWindow().getDecorView(),"دانش‌یار"),"launch Persian UI");activity.finish();
            }
            );
            result.putString("stream","PASS: "+checks+" on-device checks\n");
            finish(Activity.RESULT_OK,result);
        }
        catch(Throwable error) {
            result.putString("stream","FAIL: "+error+"\n");
            finish(Activity.RESULT_CANCELED,result);
        }
        finally {
            getContext().deleteDatabase("daneshyar.db");
        }
    }
    private boolean containsText(View view,String text) {
        if(view instanceof TextView&&((TextView)view).getText().toString().contains(text))return true;
        if(view instanceof ViewGroup) {
            ViewGroup group=(ViewGroup)view;
            for(int i=0;i<group.getChildCount();i++)if(containsText(group.getChildAt(i),text))return true;
        }
        return false;
    }
}
