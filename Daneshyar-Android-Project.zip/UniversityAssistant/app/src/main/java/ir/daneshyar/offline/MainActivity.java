package ir.daneshyar.offline;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public final class MainActivity extends Activity {
    static final int NAVY=Color.rgb(18,40,63), TEAL=Color.rgb(8,127,140), INK=Color.rgb(31,48,67), MUTED=Color.rgb(102,119,136), BG=Color.rgb(243,246,250);
    static final String[] DAYS= {
        "شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"
    };
    static final String[] KINDS= {
        "امتحان","تکلیف","پروژه","رویداد دانشگاهی"
    };
    static final String[] MONTHS= {
        "فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"
    };
    private ProgressDialog busyDialog;
    private Store db;
    private LinearLayout root,body,nav;
    private int page=0,weekDay;
    private long selectedDate=System.currentTimeMillis();
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db=new Store(this);
        weekDay=day(System.currentTimeMillis());
        if(state!=null) {
            page=state.getInt("page");
            selectedDate=state.getLong("date");
            weekDay=state.getInt("day");
        }
        Reminders.channel(this);
        Reminders.schedule(this);
        render();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("page",page);
        out.putLong("date",selectedDate);
        out.putInt("day",weekDay);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if(r==7) {
            toast(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED?"اعلان‌ها فعال شد":"اجازه اعلان داده نشد؛ از تنظیمات گوشی فعال کنید");
            render();
        }
    }
    @Override protected void onDestroy() {
        if(busyDialog!=null)busyDialog.dismiss();
        db.close();
        io.shutdown();
        super.onDestroy();
    }
    int dp(float n) {
        return Math.round(n*getResources().getDisplayMetrics().density);
    }
    LinearLayout column() {
        LinearLayout l=new LinearLayout(this);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    LinearLayout row() {
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    TextView text(String s,int size,int color) {
        TextView v=new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(0,dp(4),0,dp(4));
        return v;
    }
    TextView title(String s) {
        TextView t=text(s,21,INK);
        t.setTypeface(null,Typeface.BOLD);
        return t;
    }
    GradientDrawable surface(int color,int radius) {
        GradientDrawable d=new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    Button button(String label,Runnable action) {
        Button b=new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(TEAL);
        b.setAllCaps(false);
        b.setOnClickListener(v->action.run());
        return b;
    }
    void addButton(LinearLayout target,String label,Runnable action) {
        target.addView(button(label,action));
    }
    void heading(String s,String sub) {
        body.addView(title(s));
        body.addView(text(sub,13,MUTED));
    }
    LinearLayout card() {
        LinearLayout c=column();
        c.setPadding(dp(16),dp(12),dp(16),dp(12));
        c.setBackground(surface(Color.WHITE,18));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,dp(8),0,dp(4));
        body.addView(c,p);
        return c;
    }
    void empty(String s) {
        LinearLayout c=card();
        c.addView(text("✦",30,TEAL));
        c.addView(title(s));
        c.addView(text("با دکمه افزودن، اولین مورد را ثبت کنید.",14,MUTED));
    }
    void toast(String s) {
        Toast.makeText(this,s,Toast.LENGTH_LONG).show();
    }
    String fa(String s) {
        return PersianDates.digits(s);
    }
    String course(long id) {
        JSONObject c=db.get("courses",id);
        return c==null?"بدون درس":c.optString("name");
    }
    int day(long millis) {
        java.util.Calendar c=java.util.Calendar.getInstance();
        c.setTimeInMillis(millis);
        return c.get(java.util.Calendar.DAY_OF_WEEK)%7;
    }
    String dateLabel(long t) {
        return DAYS[day(t)]+"، "+fa(PersianDates.date(t));
    }
    boolean sameDay(long a,long b) {
        return PersianDates.date(a).equals(PersianDates.date(b));
    }
    void changed() {
        Reminders.schedule(this);
        render();
    }
    void render() {
        root=column();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v,insets)-> {
            if(Build.VERSION.SDK_INT>=30) {
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }
            else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
        }
        );
        LinearLayout header=row();
        header.setBackgroundColor(NAVY);
        header.setPadding(dp(20),dp(14),dp(16),dp(14));
        LinearLayout branding=column();
        TextView name=text("دانش‌یار",25,Color.WHITE);
        name.setTypeface(null,Typeface.BOLD);
        branding.addView(name);
        branding.addView(text("همراه دانشگاه، همیشه آفلاین",12,Color.rgb(184,216,223)));
        header.addView(branding,new LinearLayout.LayoutParams(0,-2,1));
        Button settings=button("تنظیمات",()-> {
            page=5;render();
        }
        );
        settings.setTextColor(Color.WHITE);
        header.addView(settings);
        root.addView(header);
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        body=column();
        body.setPadding(dp(18),dp(16),dp(18),dp(22));
        scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();
        nav.setBackgroundColor(Color.WHITE);
        String[] labels= {
            "امروز","هفته","رویدادها","دروس","تقویم"
        };
        for(int i=0;i<labels.length;i++) {
            final int p=i;
            TextView tab=text(labels[i],12,page==i?TEAL:MUTED);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(0,dp(18),0,dp(18));
            tab.setTypeface(null,page==i?Typeface.BOLD:Typeface.NORMAL);
            tab.setOnClickListener(v-> {
                page=p;render();
            }
            );
            nav.addView(tab,new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(nav);
        setContentView(root);
        root.requestApplyInsets();
        if(page==0)today();
        else if(page==1)week();
        else if(page==2)events();
        else if(page==3)courses();
        else if(page==4)calendar();
        else settings();
    }
    void today() {
        long now=System.currentTimeMillis();
        heading("یک روز منظم، یک قدم جلوتر",dateLabel(now));
        int count=0,units=0;
        double weighted=0,graded=0;
        for(JSONObject c:db.all("courses")) {
            units+=c.optInt("units");
            if(!c.isNull("grade")) {
                graded+=c.optInt("units");
                weighted+=c.optDouble("grade")*c.optInt("units");
            }
        }
        for(JSONObject e:db.all("events"))if(e.optInt("done")==0&&e.optLong("due")>=now)count++;
        LinearLayout summary=card();
        summary.setBackground(surface(NAVY,18));
        summary.addView(text(fa(units+" واحد  •  "+count+" مهلت پیش رو"),20,Color.WHITE));
        summary.addView(text("معدل ثبت‌شده: "+(graded==0?"—":fa(String.format(Locale.US,"%.2f",weighted/graded))),14,Color.rgb(184,216,223)));
        body.addView(title("کلاس‌های امروز"));
        daily(now);
        body.addView(title("مهلت‌های نزدیک"));
        int n=0;
        for(JSONObject e:db.all("events"))if(e.optInt("done")==0) {
            eventCard(e);
            if(++n==4)break;
        }
        if(n==0)empty("فعلاً مهلتی ثبت نشده");
        addButton(body,"＋ ثبت رویداد",()->editEvent(null));
    }
    void daily(long date) {
        int n=0;
        for(JSONObject s:db.all("sessions"))if(s.optInt("day")==day(date)) {
            sessionCard(s);
            n++;
        }
        if(n==0) {
            LinearLayout c=card();
            c.addView(text("امروز کلاسی ندارید",16,MUTED));
        }
    }
    void week() {
        heading("برنامهٔ هفتگی","هر جلسهٔ درس را جداگانه ثبت کنید");
        HorizontalScrollView strip=new HorizontalScrollView(this);
        LinearLayout choices=row();
        for(int i=0;i<7;i++) {
            final int d=i;
            Button b=button(DAYS[i],()-> {
                weekDay=d;render();
            }
            );
            if(i==weekDay)b.setTextColor(NAVY);
            choices.addView(b);
        }
        strip.addView(choices);
        body.addView(strip);
        int n=0;
        for(JSONObject s:db.all("sessions"))if(s.optInt("day")==weekDay) {
            sessionCard(s);
            n++;
        }
        if(n==0)empty("برنامهٔ "+DAYS[weekDay]+" خالی است");
        addButton(body,"＋ افزودن جلسهٔ کلاس",()->editSession(null));
    }
    void sessionCard(JSONObject s) {
        LinearLayout c=card();
        c.addView(title(course(s.optLong("course_id"))));
        c.addView(text(fa(PersianDates.clock(s.optInt("start"))+" تا "+PersianDates.clock(s.optInt("end")))+"  •  "+s.optString("room"),15,TEAL));
        c.addView(text("یادآوری: "+(s.optInt("remind")<0?"خاموش":fa(s.optInt("remind")+" دقیقه پیش از کلاس")),12,MUTED));
        c.setOnClickListener(v->editSession(s));
        c.addView(text("برای ویرایش یا حذف لمس کنید",11,MUTED));
    }
    void events() {
        heading("رویدادها و مهلت‌ها","امتحان، تکلیف، پروژه و مناسبت دانشگاه");
        addButton(body,"＋ افزودن رویداد",()->editEvent(null));
        List<JSONObject> all=db.all("events");
        if(all.isEmpty())empty("رویدادی ثبت نشده");
        for(JSONObject e:all)eventCard(e);
    }
    void eventCard(JSONObject e) {
        LinearLayout c=card();
        boolean done=e.optInt("done")==1;
        long due=e.optLong("due");
        c.addView(text(KINDS[e.optInt("kind")]+"  •  "+(done?"انجام شد":due<System.currentTimeMillis()?"مهلت گذشته":"در انتظار"),12,done?MUTED:TEAL));
        c.addView(title(e.optString("title")));
        c.addView(text(dateLabel(due)+"  ·  "+fa(PersianDates.time(due)),14,MUTED));
        if(!e.isNull("course_id"))c.addView(text(course(e.optLong("course_id")),13,TEAL));
        if(!e.optString("notes").isEmpty())c.addView(text(e.optString("notes"),14,INK));
        LinearLayout actions=row();
        actions.addView(button("ویرایش",()->editEvent(e)));
        actions.addView(button(done?"بازگشایی":"انجام شد",()-> {
            ContentValues values=new ContentValues();values.put("done",done?0:1);db.save("events",e.optLong("id"),values);changed();
        }
        ));
        c.addView(actions);
    }
    void courses() {
        heading("دروس و کارنامه","نمره از ۲۰ • معدل با وزن واحدها");
        LinearLayout buttons=row();
        buttons.addView(button("＋ درس",()->editCourse(null)));
        buttons.addView(button("اساتید",this::teachers));
        body.addView(buttons);
        List<JSONObject> all=db.all("courses");
        if(all.isEmpty())empty("اولین درس را اضافه کنید");
        for(JSONObject c:all) {
            LinearLayout view=card();
            view.addView(title(c.optString("name")));
            JSONObject teacher=db.get("teachers",c.optLong("teacher_id"));
            view.addView(text(teacher==null?"استاد مشخص نشده":teacher.optString("name"),14,MUTED));
            view.addView(text(fa(c.optInt("units")+" واحد")+"  •  نمره: "+(c.isNull("grade")?"ثبت نشده":fa(c.optString("grade"))),15,TEAL));
            view.addView(button("ویرایش درس",()->editCourse(c)));
        }
    }
    void teachers() {
        LinearLayout list=column();
        list.setPadding(dp(18),dp(10),dp(18),dp(10));
        addButton(list,"＋ افزودن استاد",()->editTeacher(null));
        for(JSONObject t:db.all("teachers")) {
            list.addView(button(t.optString("name")+" · "+t.optString("contact"),()->editTeacher(t)));
        }
        ScrollView scroll=new ScrollView(this);
        scroll.addView(list);
        new AlertDialog.Builder(this).setTitle("اساتید").setView(scroll).setNegativeButton("بستن",null).show();
    }
    void calendar() {
        android.icu.util.Calendar current=PersianDates.calendar(selectedDate);
        int year=current.get(android.icu.util.Calendar.YEAR),month=current.get(android.icu.util.Calendar.MONTH);
        heading("تقویم دانشگاهی",MONTHS[month]+" "+fa(""+year));
        LinearLayout controls=row();
        controls.addView(button("ماه قبل",()->shiftMonth(-1)));
        controls.addView(button("امروز",()-> {
            selectedDate=System.currentTimeMillis();render();
        }
        ));
        controls.addView(button("ماه بعد",()->shiftMonth(1)));
        body.addView(controls);
        android.icu.util.Calendar first=PersianDates.calendar(selectedDate);
        first.set(android.icu.util.Calendar.DAY_OF_MONTH,1);
        List<JSONObject> calendarEvents=db.all("events");
        int offset=day(first.getTimeInMillis()),days=first.getActualMaximum(android.icu.util.Calendar.DAY_OF_MONTH);
        LinearLayout grid=card();
        LinearLayout line=row();
        String[] shortDays= {
            "ش","ی","د","س","چ","پ","ج"
        };
        for(String label:shortDays) {
            TextView t=text(label,14,MUTED);
            t.setGravity(Gravity.CENTER);
            line.addView(t,new LinearLayout.LayoutParams(0,dp(36),1));
        }
        grid.addView(line);
        for(int cell=0;cell<((offset+days+6)/7)*7;cell++) {
            if(cell%7==0) {
                line=row();
                grid.addView(line);
            }
            int date=cell-offset+1;
            if(date<1||date>days) {
                line.addView(new TextView(this),new LinearLayout.LayoutParams(0,dp(48),1));
                continue;
            }
            android.icu.util.Calendar cal=PersianDates.calendar(first.getTimeInMillis());
            cal.set(android.icu.util.Calendar.DAY_OF_MONTH,date);
            final long value=cal.getTimeInMillis();
            boolean has=false;
            for(JSONObject e:calendarEvents)if(sameDay(value,e.optLong("due")))has=true;
            TextView cellView=text(fa(""+date)+(has?" •":""),13,sameDay(value,selectedDate)?Color.WHITE:INK);
            cellView.setGravity(Gravity.CENTER);
            if(sameDay(value,selectedDate))cellView.setBackground(surface(TEAL,12));
            cellView.setContentDescription(dateLabel(value)+(has?" دارای رویداد":""));
            cellView.setOnClickListener(v-> {
                selectedDate=value;render();
            }
            );
            line.addView(cellView,new LinearLayout.LayoutParams(0,dp(48),1));
        }
        body.addView(title(dateLabel(selectedDate)));
        daily(selectedDate);
        for(JSONObject e:db.all("events"))if(sameDay(selectedDate,e.optLong("due")))eventCard(e);
        addButton(body,"＋ رویداد در این روز",()->editEvent(null));
    }
    void shiftMonth(int delta) {
        android.icu.util.Calendar c=PersianDates.calendar(selectedDate);
        c.set(android.icu.util.Calendar.DAY_OF_MONTH,1);
        c.add(android.icu.util.Calendar.MONTH,delta);
        selectedDate=c.getTimeInMillis();
        render();
    }
    LinearLayout form() {
        LinearLayout f=column();
        f.setPadding(dp(20),dp(12),dp(20),dp(12));
        return f;
    }
    EditText input(LinearLayout f,String label,String value,boolean number) {
        f.addView(text(label,13,MUTED));
        EditText e=new EditText(this);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(number?InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL:InputType.TYPE_CLASS_TEXT);
        e.setFilters(new android.text.InputFilter[] {
            new android.text.InputFilter.LengthFilter(4000)
        }
        );
        f.addView(e,new LinearLayout.LayoutParams(-1,-2));
        return e;
    }
    Spinner select(LinearLayout f,String label,String[] labels,int pos) {
        f.addView(text(label,13,MUTED));
        Spinner s=new Spinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(Math.max(0,pos));
        f.addView(s);
        return s;
    }
    interface SaveAction {
        void run() throws Exception;
    }
    void dialog(String title,LinearLayout f,String table,JSONObject old,SaveAction save) {
        ScrollView scroll=new ScrollView(this);
        scroll.addView(f);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("ذخیره",null).setNegativeButton("انصراف",null);
        if(old!=null)b.setNeutralButton("حذف",null);
        AlertDialog d=b.create();
        d.setOnShowListener(v-> {
            d.getButton(-1).setOnClickListener(view-> {
                try {
                    save.run();changed();d.dismiss();
                }
                catch(Exception ex) {
                    toast("ذخیره نشد: "+(ex.getMessage()==null?"اطلاعات نامعتبر":ex.getMessage()));
                }
            }
            );if(old!=null)d.getButton(-3).setOnClickListener(view->new AlertDialog.Builder(this).setTitle("حذف اطلاعات؟").setMessage(table.equals("courses")?"جلسه‌های این درس هم حذف می‌شوند؛ رویدادها باقی می‌مانند.":"این عمل قابل بازگشت نیست؛ نسخه پشتیبان تهیه کنید.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(a,w)-> {
                db.delete(table,old.optLong("id"));changed();d.dismiss();
            }
            ).show());
        }
        );
        d.show();
    }
    String value(JSONObject old,String key,String fallback) {
        return old==null||old.isNull(key)?fallback:old.optString(key,fallback);
    }
    long id(JSONObject old) {
        return old==null?0:old.optLong("id");
    }
    String required(EditText e) {
        String s=e.getText().toString().trim();
        if(s.isEmpty())throw new IllegalArgumentException("عنوان یا نام را وارد کنید");
        return s;
    }
    int integer(EditText e) {
        return Integer.parseInt(PersianDates.ascii(e.getText().toString()));
    }
    void editTeacher(JSONObject old) {
        LinearLayout f=form();
        EditText name=input(f,"نام استاد",value(old,"name",""),false),contact=input(f,"راه ارتباطی (اختیاری)",value(old,"contact",""),false),office=input(f,"اتاق / ساعت مراجعه",value(old,"office",""),false);
        dialog("اطلاعات استاد",f,"teachers",old,()-> {
            ContentValues v=new ContentValues();v.put("name",required(name));v.put("contact",contact.getText().toString());v.put("office",office.getText().toString());db.save("teachers",id(old),v);
        }
        );
    }
    String[] names(List<JSONObject> rows,boolean optional) {
        String[] a=new String[rows.size()+(optional?1:0)];
        int i=0;
        if(optional)a[i++]="انتخاب نشده";
        for(JSONObject r:rows)a[i++]=r.optString("name");
        return a;
    }
    int position(List<JSONObject> rows,long id,boolean optional) {
        for(int i=0;i<rows.size();i++)if(rows.get(i).optLong("id")==id)return i+(optional?1:0);
        return 0;
    }
    void link(ContentValues v,String key,Spinner spinner,List<JSONObject> list,boolean optional) {
        int index=spinner.getSelectedItemPosition()-(optional?1:0);
        if(index<0)v.putNull(key);
        else v.put(key,list.get(index).optLong("id"));
    }
    void editCourse(JSONObject old) {
        LinearLayout f=form();
        EditText name=input(f,"نام درس",value(old,"name",""),false);
        List<JSONObject> teachers=db.all("teachers");
        Spinner teacher=select(f,"استاد (در صفحه دروس ← اساتید اضافه کنید)",names(teachers,true),position(teachers,old==null?0:old.optLong("teacher_id"),true));
        EditText units=input(f,"تعداد واحد (۱ تا ۱۲)",value(old,"units","3"),true),grade=input(f,"نمره (۰ تا ۲۰؛ خالی یعنی ثبت نشده)",value(old,"grade",""),true);
        dialog("اطلاعات درس",f,"courses",old,()-> {
            ContentValues v=new ContentValues();v.put("name",required(name));int u=integer(units);if(u<1||u>12)throw new IllegalArgumentException("واحد بین ۱ و ۱۲ باشد");v.put("units",u);String g=PersianDates.ascii(grade.getText().toString());if(g.isEmpty())v.putNull("grade");else {
                double n=Double.parseDouble(g);if(!Double.isFinite(n)||n<0||n>20)throw new IllegalArgumentException("نمره بین ۰ و ۲۰ باشد");v.put("grade",n);
            }
            link(v,"teacher_id",teacher,teachers,true);db.save("courses",id(old),v);
        }
        );
    }
    void editSession(JSONObject old) {
        List<JSONObject> courses=db.all("courses");
        if(courses.isEmpty()) {
            toast("ابتدا یک درس اضافه کنید");
            page=3;
            render();
            return;
        }
        LinearLayout f=form();
        Spinner course=select(f,"درس",names(courses,false),position(courses,old==null?0:old.optLong("course_id"),false));
        Spinner d=select(f,"روز هفته",DAYS,old==null?weekDay:old.optInt("day"));
        EditText start=input(f,"شروع (۰۹:۳۰)",old==null?"09:00":PersianDates.clock(old.optInt("start")),false),end=input(f,"پایان (۱۱:۰۰)",old==null?"11:00":PersianDates.clock(old.optInt("end")),false),room=input(f,"کلاس / ساختمان",value(old,"room",""),false),lead=input(f,"دقیقه قبل برای یادآوری؛ خالی = خاموش",old==null?"15":old.optInt("remind")<0?"":old.optString("remind"),true);
        dialog("جلسهٔ کلاس",f,"sessions",old,()-> {
            ContentValues v=new ContentValues();int s=PersianDates.minutes(start.getText().toString()),e=PersianDates.minutes(end.getText().toString());if(e<=s)throw new IllegalArgumentException("پایان باید بعد از شروع باشد");int minutes=lead.getText().toString().trim().isEmpty()?-1:integer(lead);if(minutes< -1||minutes>1440)throw new IllegalArgumentException("یادآوری حداکثر ۱۴۴۰ دقیقه باشد");
            long courseId=courses.get(course.getSelectedItemPosition()).optLong("id");for(JSONObject other:db.all("sessions"))if(other.optLong("id")!=id(old)&&other.optInt("day")==d.getSelectedItemPosition()&&s<other.optInt("end")&&e>other.optInt("start"))throw new IllegalArgumentException("این ساعت با یک کلاس دیگر تداخل دارد");
            v.put("course_id",courseId);v.put("day",d.getSelectedItemPosition());v.put("start",s);v.put("end",e);v.put("room",room.getText().toString());v.put("remind",minutes);db.save("sessions",id(old),v);
        }
        );
    }
    void editEvent(JSONObject old) {
        LinearLayout f=form();
        EditText name=input(f,"عنوان",value(old,"title",""),false);
        Spinner kind=select(f,"نوع",KINDS,old==null?0:old.optInt("kind"));
        List<JSONObject> courses=db.all("courses");
        Spinner course=select(f,"درس مرتبط (اختیاری)",names(courses,true),position(courses,old==null?0:old.optLong("course_id"),true));
        long initial=old==null?(page==4?selectedDate:System.currentTimeMillis()):old.optLong("due");
        EditText date=input(f,"تاریخ شمسی (سال/ماه/روز)",PersianDates.date(initial),false),time=input(f,"ساعت (۲۴ ساعته)",old==null?"09:00":PersianDates.time(initial),false),lead=input(f,"یادآوری، دقیقه قبل؛ خالی = خاموش",old==null?"60":old.optInt("lead")<0?"":old.optString("lead"),true),notes=input(f,"توضیحات",value(old,"notes",""),false);
        notes.setSingleLine(false);
        notes.setMinLines(2);
        dialog("رویداد و مهلت",f,"events",old,()-> {
            long due=PersianDates.parse(date.getText().toString(),time.getText().toString());int minutes=lead.getText().toString().trim().isEmpty()?-1:integer(lead);if(minutes< -1||minutes>10080)throw new IllegalArgumentException("یادآوری حداکثر یک هفته قبل باشد");ContentValues v=new ContentValues();v.put("title",required(name));v.put("kind",kind.getSelectedItemPosition());link(v,"course_id",course,courses,true);v.put("due",due);v.put("lead",minutes);v.put("done",old==null?0:old.optInt("done"));v.put("notes",notes.getText().toString());db.save("events",id(old),v);if(minutes>=0&&due-minutes*60000L<=System.currentTimeMillis())toast("زمان یادآوری گذشته است؛ رویداد ذخیره شد ولی اعلان گذشته ارسال نمی‌شود");
        }
        );
    }
    void settings() {
        heading("تنظیمات و نسخهٔ پشتیبان","اطلاعات فقط روی دستگاه شماست");
        LinearLayout info=card();
        info.addView(title("آفلاین و خصوصی"));
        info.addView(text("بدون حساب کاربری، سرور، تبلیغات یا مجوز اینترنت. فایل پشتیبان شامل اطلاعات شخصی است؛ آن را در محل امن ذخیره کنید.",14,MUTED));
        LinearLayout notifications=card();
        notifications.addView(title("اعلان‌های محلی"));
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch=nm.getNotificationChannel(Reminders.CHANNEL);
        boolean enabled=nm.areNotificationsEnabled()&&ch!=null&&ch.getImportance()!=NotificationManager.IMPORTANCE_NONE;
        notifications.addView(text(enabled?"اعلان‌ها فعال هستند":"اعلان‌ها خاموش هستند",14,TEAL));
        notifications.addView(text("یادآوری‌ها ممکن است به‌دلیل صرفه‌جویی باتری با تأخیر نمایش داده شوند. پس از توقف اجباری برنامه، آن را دوباره باز کنید. کلاس‌ها هر هفته تکرار می‌شوند؛ در تعطیلات یادآوری جلسه را خاموش کنید.",13,MUTED));
        addButton(notifications,"اجازه / تنظیم اعلان‌ها",()-> {
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[] {
                Manifest.permission.POST_NOTIFICATIONS
            },7);else {
                Intent i=new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName());startActivity(i);
            }
        }
        );
        addButton(notifications,"آزمون اعلان",()-> {
            Reminders.notify(this,"این یک یادآوری آزمایشی است",-1);toast("اگر اجازه اعلان فعال باشد، اعلان آزمایشی نمایش داده می‌شود");
        }
        );
        LinearLayout backup=card();
        backup.addView(title("پشتیبان‌گیری محلی"));
        backup.addView(text("برای حفظ آفلاین بودن، در انتخابگر فایل پوشهٔ حافظهٔ گوشی را انتخاب کنید. بازیابی، اطلاعات فعلی را جایگزین می‌کند.",14,MUTED));
        addButton(backup,"ذخیره نسخهٔ پشتیبان",()-> {
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"daneshyar-"+PersianDates.date(System.currentTimeMillis()).replace('/','-')+".json");startActivityForResult(i,10);
        }
        );
        addButton(backup,"بازیابی از فایل",()-> {
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,11);
        }
        );
        LinearLayout about=card();
        about.addView(text("دانش‌یار • نسخه ۱.۰\nتقویم شمسی دستگاه • SQLite محلی\nاندروید ۸ و بالاتر",14,MUTED));
    }
    @Override protected void onResume() {
        super.onResume();
        if(db!=null&&root!=null) {
            Reminders.schedule(this);
            render();
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==10)exportBackup(uri);
        else if(request==11)new AlertDialog.Builder(this).setTitle("جایگزینی اطلاعات؟").setMessage("تمام اطلاعات فعلی با فایل انتخاب‌شده جایگزین می‌شود. پیش از ادامه نسخه پشتیبان تهیه کنید.").setNegativeButton("انصراف",null).setPositiveButton("بازیابی",(d,w)->importBackup(uri)).show();
    }
    void exportBackup(Uri uri) {
        ProgressDialog progress=ProgressDialog.show(this,"نسخهٔ پشتیبان","در حال ذخیره…",true,false);
        busyDialog=progress;
        io.execute(()-> {
            String message;try(Store store=new Store(getApplicationContext())) {
                byte[] bytes=store.backup().toString(2).getBytes(StandardCharsets.UTF_8);try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
                    if(out==null)throw new IOException("فایل باز نشد");out.write(bytes);
                }
                message="نسخهٔ پشتیبان ذخیره شد";
            }
            catch(Exception e) {
                message="ذخیره ناموفق: "+e.getMessage();
            }
            final String result=message;runOnUiThread(()-> {
                if(!isFinishing()&&!isDestroyed()) {
                    progress.dismiss();toast(result);
                }
            }
            );
        }
        );
    }
    void importBackup(Uri uri) {
        ProgressDialog progress=ProgressDialog.show(this,"بازیابی","در حال بررسی فایل…",true,false);
        busyDialog=progress;
        io.execute(()-> {
            String message;try(InputStream in=getContentResolver().openInputStream(uri);Store store=new Store(getApplicationContext())) {
                if(in==null)throw new IOException("فایل باز نشد");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1) {
                    if(out.size()+n>5*1024*1024)throw new IOException("فایل بزرگ‌تر از ۵ مگابایت است");out.write(buffer,0,n);
                }
                store.restore(new JSONObject(out.toString("UTF-8")));message="اطلاعات بازیابی شد";try {
                    Reminders.schedule(getApplicationContext());
                }
                catch(RuntimeException alarmError) {
                    message="اطلاعات بازیابی شد؛ زمان‌بندی اعلان‌ها ناموفق بود. برنامه را دوباره باز کنید";
                }
            }
            catch(Exception e) {
                message="بازیابی ناموفق؛ اطلاعات قبلی حفظ شد: "+e.getMessage();
            }
            final String result=message;runOnUiThread(()-> {
                if(!isFinishing()&&!isDestroyed()) {
                    progress.dismiss();toast(result);render();
                }
            }
            );
        }
        );
    }
}
