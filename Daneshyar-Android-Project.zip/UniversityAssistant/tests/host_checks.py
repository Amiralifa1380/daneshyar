#!/usr/bin/env python3
"""Checks the actual SQL schema and executes extracted pure Java methods.
Not an Android build, emulator test, or substitute for on-device tests.
"""
from pathlib import Path
import sqlite3, re, subprocess, os, tempfile, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/ir/daneshyar/offline'
passed = 0

def check(condition, name):
    global passed
    assert condition, name
    passed += 1
    print('PASS:', name)

def rejects(db, sql, args, name):
    try:
        db.execute(sql, args)
    except sqlite3.IntegrityError:
        check(True, name)
    else:
        raise AssertionError(name)

connection = sqlite3.connect(':memory:')
connection.execute('PRAGMA foreign_keys=ON')
for sql in re.findall(r'db\.execSQL\("([^"]+)"\)', (SRC/'Store.java').read_text()):
    connection.execute(sql)
check(len(connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name!='sqlite_sequence'").fetchall()) == 4, 'four tables from actual source schema')
connection.execute('INSERT INTO teachers(name) VALUES(?)', ('استاد',))
connection.execute('INSERT INTO courses(name,teacher_id,units,grade) VALUES(?,?,?,?)', ('ریاضی', 1, 3, 18.5))
connection.execute('INSERT INTO sessions(course_id,day,start,end,remind) VALUES(?,?,?,?,?)', (1, 0, 540, 600, 15))
connection.execute('INSERT INTO events(title,kind,course_id,due,lead) VALUES(?,?,?,?,?)', ('آزمون', 0, 1, 1800000000000, 60))
check(connection.execute('SELECT grade FROM courses').fetchone()[0] == 18.5, 'grade and units persisted')
rejects(connection, 'INSERT INTO courses(name,units,grade) VALUES(?,?,?)', ('نام', 3, 21), 'reject grade outside 0..20')
rejects(connection, 'INSERT INTO courses(name,units) VALUES(?,?)', ('نام', 0), 'reject invalid credits')
rejects(connection, 'INSERT INTO sessions(course_id,day,start,end,remind) VALUES(?,?,?,?,?)', (1, 7, 10, 20, 0), 'reject invalid weekday')
rejects(connection, 'INSERT INTO sessions(course_id,day,start,end,remind) VALUES(?,?,?,?,?)', (1, 1, 600, 540, 0), 'reject reversed class times')
rejects(connection, 'INSERT INTO events(title,kind,course_id,due,lead) VALUES(?,?,?,?,?)', ('نام', 0, 999, 1, 0), 'reject orphan course link')
rejects(connection, 'INSERT INTO events(title,kind,due,lead) VALUES(?,?,?,?)', ('نام', 4, 1, 0), 'reject invalid event kind')
connection.commit()
try:
    with connection:
        connection.execute('DELETE FROM events')
        connection.execute('INSERT INTO events(title,kind,due,lead) VALUES(?,?,?,?)', ('خراب', 0, -1, 60))
except sqlite3.IntegrityError:
    pass
check(connection.execute('SELECT title FROM events').fetchone()[0] == 'آزمون', 'SQLite restores previous data after transaction error')
connection.execute('DELETE FROM teachers WHERE id=?', (1,))
check(connection.execute('SELECT teacher_id FROM courses').fetchone()[0] is None, 'teacher removal preserves course')
connection.execute('DELETE FROM courses WHERE id=?', (1,))
check(connection.execute('SELECT count(*) FROM sessions').fetchone()[0] == 0, 'course removal cascades weekly sessions')
check(connection.execute('SELECT course_id FROM events').fetchone()[0] is None, 'course removal preserves events')
payload = "x'); DROP TABLE events; --"
connection.execute('INSERT INTO teachers(name) VALUES(?)', (payload,))
check(connection.execute('SELECT name FROM teachers').fetchone()[0] == payload, 'parameter binding stores SQL-shaped input safely')
for file in (ROOT/'app/src/main').rglob('*.xml'):
    ET.parse(file)
check(True, 'all Android resource XML parses')
base_theme = ET.parse(ROOT/'app/src/main/res/values/styles.xml').getroot()
v27_theme = ET.parse(ROOT/'app/src/main/res/values-v27/styles.xml').getroot()
check(not any(i.get('name') == 'android:windowLightNavigationBar' for i in base_theme.iter('item')), 'API 27 navigation property excluded from API 26 defaults')
check(any(i.get('name') == 'android:windowLightNavigationBar' for i in v27_theme.iter('item')), 'API 27 navigation property version-qualified')
manifest = ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
permissions = [x.get('{http://schemas.android.com/apk/res/android}name') for x in manifest.findall('uses-permission')]
check('android.permission.INTERNET' not in permissions, 'no INTERNET permission')
check(not re.search(r'https?://|HttpURLConnection|Socket\(', '\n'.join(p.read_text() for p in SRC.glob('*.java'))), 'no network calls or remote resources in Java sources')

def method(text, name):
    start = text.index('    public static ' + name) if name.startswith(('String ', 'int ', 'long ')) else -1
    brace = text.index('{', start)
    depth = 1
    i = brace + 1
    while depth:
        if text[i] == '{': depth += 1
        elif text[i] == '}': depth -= 1
        i += 1
    return text[start:i]

persian = (SRC/'PersianDates.java').read_text()
reminders = (SRC/'Reminders.java').read_text()
methods = '\n'.join(method(persian, n) for n in ['String ascii(', 'int minutes(', 'String clock(', 'String digits('])
java = '''import java.util.*;
class HostLogic {
 static int checks=0;
 static void check(boolean c,String n){if(!c)throw new AssertionError(n);checks++;}
 static class JSONObject {Map<String,Integer> values=new HashMap<>();JSONObject put(String k,int v){values.put(k,v);return this;}int optInt(String k){return values.getOrDefault(k,0);}}
 static class TimeRules { METHODS }
 static class ReminderRules { REMINDER }
 public static void main(String[] args){
  TimeZone.setDefault(TimeZone.getTimeZone("Asia/Tehran"));
  check(TimeRules.minutes("۰۹:۳۰")==570,"Persian numerals");
  check(TimeRules.minutes("٠٩:٣٠")==570,"Arabic numerals");
  check(TimeRules.clock(1439).equals("23:59"),"last minute");
  check(TimeRules.digits("123").equals("۱۲۳"),"localized digits");
  for(String value:List.of("24:00","09:60","-1:00","bad")){boolean bad=false;try{TimeRules.minutes(value);}catch(Exception e){bad=true;}check(bad,"invalid time "+value);}
  Calendar now=Calendar.getInstance();now.set(2026,9,17,8,0,0);now.set(Calendar.MILLISECOND,0);
  JSONObject row=new JSONObject().put("day",0).put("start",540).put("remind",15);
  long next=ReminderRules.nextSession(row,now.getTimeInMillis());
  check(next-now.getTimeInMillis()==45*60000L,"Saturday next reminder");
  check(ReminderRules.nextSession(row,next)==next+7*86400000L,"delivered reminder advances a week");
  row.put("day",1).put("start",10).put("remind",30);
  Calendar expected=(Calendar)now.clone();expected.set(Calendar.HOUR_OF_DAY,23);expected.set(Calendar.MINUTE,40);
  check(ReminderRules.nextSession(row,now.getTimeInMillis())==expected.getTimeInMillis(),"Sunday reminder crosses to Saturday");
  for(int today=0;today<7;today++)for(int target=0;target<7;target++){
   Calendar anchor=Calendar.getInstance();anchor.set(2026,9,17+today,8,0,0);anchor.set(Calendar.MILLISECOND,0);
   row.put("day",target).put("start",540).put("remind",0);
   long actual=ReminderRules.nextSession(row,anchor.getTimeInMillis());
   check(actual-anchor.getTimeInMillis()==((target-today+7)%7)*86400000L+3600000L,"weekday mapping");
  }
  TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
  now=Calendar.getInstance();now.set(2026,2,7,10,0,0);now.set(Calendar.MILLISECOND,0);
  row.put("day",0).put("start",540).put("remind",0);
  next=ReminderRules.nextSession(row,now.getTimeInMillis());Calendar actual=Calendar.getInstance();actual.setTimeInMillis(next);
  check(actual.get(Calendar.HOUR_OF_DAY)==9&&actual.get(Calendar.DAY_OF_MONTH)==14,"DST keeps local class time");
  System.out.println("PASS: "+checks+" Java time/weekly-reminder assertions from actual source methods");
 }
}
'''.replace('METHODS', methods).replace('REMINDER', method(reminders, 'long nextSession('))
with tempfile.TemporaryDirectory() as tmp:
    path=Path(tmp)/'HostLogic.java';path.write_text(java)
    subprocess.run(['java',str(path)],check=True)
subprocess.run(['java',str(ROOT/'tests/ParseJava.java'),*[str(p) for p in (ROOT/'app/src').rglob('*.java')]],check=True)
print(f'PASS: {passed} host schema/XML/security checks. Android build and device tests NOT executed.')
