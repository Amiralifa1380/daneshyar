#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! command -v java >/dev/null; then
  echo 'JDK 17 is required.' >&2; exit 1
fi
if ! command -v gradle >/dev/null; then
  echo 'Gradle 8.9 is required. Install it or open this project in Android Studio.' >&2; exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" && ! -f local.properties ]]; then
  echo 'Set ANDROID_HOME to an Android SDK with API 35, or set sdk.dir in local.properties.' >&2; exit 1
fi
gradle --no-daemon :app:assembleDebug :app:lintDebug "$@"
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/Daneshyar-1.0.apk
echo 'APK: dist/Daneshyar-1.0.apk (debug signed, installable, not a production release signature)'
